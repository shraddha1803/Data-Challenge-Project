/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/

package sim.app.wcss.tutorial02;

public class Student
    {
    private static final long serialVersionUID = 1;

    } 
    
