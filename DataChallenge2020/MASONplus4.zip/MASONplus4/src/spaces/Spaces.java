package spaces;

public enum Spaces {
	SPARSE,OBJECT,CONTINUOUS
}
