package randomWalker;

import java.awt.Color;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.portrayal.simple.OvalPortrayal2D;
import sim.util.Double2D;
import spaces.Spaces;
import sweep.GUIStateSweep;
import sweep.SimStateSweep;

public class RandomWalkerContinuous implements Steppable {
	final static double PIx2 = Math.PI*2; 
	final static double PI = Math.PI;
	double x;
	double y;
	double xdir;
	double ydir;
	double stepSize;
	Spaces spaces;
	boolean bounded;
	boolean uniqueLocation; //find a unique location if possible
	boolean toroidal; //if false, space is bounded: the only two possiblilities allowed
	double discretation;
	boolean gaussian;
	double gaussianDirection; //north
	double gaussanStandardDeviation;
	
	
	public RandomWalkerContinuous(RandomWalkerContinousEnvironment state, double x, double y, double stepSize, Spaces spaces, boolean bounded) {
		super();
		this.x = x;
		this.y = y;
		this.stepSize = stepSize;
		this.spaces = spaces;
		this.bounded = bounded;
		uniqueLocation = state.uniqueLocation; //find a unique location if possible
		toroidal = state.toroidal; //if false, space is bounded: the only two possiblilities allowed
		discretation =state.discretation;;
		gaussian = state.gaussian;
		gaussianDirection = state.gaussianDirection; //north
		gaussanStandardDeviation = state.gaussanStandardDeviation;
	}

	public void setColor(SimStateSweep state, float red, float green, float blue, float opacity){
		Color c = new Color(red,green,blue,opacity);
		OvalPortrayal2D o = new OvalPortrayal2D(c);
		GUIStateSweep guiState = (GUIStateSweep)state.gui;
		switch(spaces){
		case OBJECT: guiState.agentsPortrayalObject.setPortrayalForObject(this, o);
		break;
		case SPARSE: guiState.agentsPortrayalSparseGrid.setPortrayalForObject(this, o);
		break;
		case CONTINUOUS: guiState.agentsPortrayalContnuous.setPortrayalForObject(this, o);
		}

	}	
	
	/**
	 * Agents take a uniform random step in continuous 2D space.  The size of the step is determined by stepSize.
	 * StepSize could be made variable.  A random angle is generated and the direction vectors xdir and ydir are
	 * found by taking the cos and sin of the angle repsectively.  It is assumed that the agent is moving on a torus
	 * and the x and y coordinates are corrected for a toroidal space.
	 * @param state
	 * @return
	 */
	
	public Double2D randomStepToris(SimState state){
		double randomAngle = state.random.nextDouble() * PIx2; //360 random angle
		xdir = Math.cos(randomAngle) * stepSize;
		ydir = Math.sin(randomAngle) * stepSize;
		RandomWalkerContinousEnvironment s = (RandomWalkerContinousEnvironment) state;
		x = s.continuousSpace.stx(x+xdir);
		y = s.continuousSpace.stx(y+ydir);
		return new Double2D(x,y);
	}
	
	/**
	 * Agents take a Guassian random step in continuous 2D space.  The size of the step is determined by stepSize.
	 * StepSize could be made variable.  A random angle is generated from the rotation provided and the standard
	 * deviation for the Gaussian distribution and the direction vectors xdir and ydir are again
	 * found by taking the cos and sin of the angle repsectively.  It is assumed that the agent is moving on a torus
	 * and the x and y coordinates are corrected for a toroidal space.
	 * @param state
	 * @param sd
	 * @param rotation
	 * @return
	 */
	
	public Double2D randomGaussianStepToris(SimState state,double sd, double rotation){
		double randomAngle = state.random.nextGaussian() * sd + rotation; //360 random angle
		xdir = Math.cos(randomAngle) * stepSize;
		ydir = Math.sin(randomAngle) * stepSize;
		RandomWalkerContinousEnvironment s = (RandomWalkerContinousEnvironment) state;
		x = s.continuousSpace.stx(x+xdir);
		y = s.continuousSpace.stx(y+ydir);
		return new Double2D(x,y);
	}
	
	public void step(SimState state) {
		Double2D newLocation;
		if(gaussian)
			newLocation = randomGaussianStepToris(state,gaussanStandardDeviation,PI*gaussianDirection);
		else
			newLocation = randomStepToris(state);
		RandomWalkerContinousEnvironment s = (RandomWalkerContinousEnvironment) state;
		s.continuousSpace.setObjectLocation(this, newLocation);
	}

}
